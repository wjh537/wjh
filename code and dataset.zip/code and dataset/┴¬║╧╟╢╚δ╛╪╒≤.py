
import os
os.environ["TF_CPP_MIN_LOG_LEVEL"]="3"
import re
import pickle
import time
import operator
import datetime
import numpy as np
import pandas as pd
from math import sqrt
import tensorflow as tf
#from copy import deepcopy
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

#******************************数据处理***************************************************

def results1(m,s):
    with open('.\ml-1m\联合嵌入CNN结果统计3 ','a') as f:
        f.write("此次运行的"+s+str(m)+'\n') 
       
def results2(e,l,b,f):
   with open('.\ml-1m\联合嵌入CNN结果统计3 ','a') as f:
        f.write("其他超参分别为："+str(e)+','+str(l)+','+str(b)+','+str(f)+'\n')
                
def load_data():#加载数据
    #读取User数据
    users_title = ['UserID', 'Gender', 'Age', 'JobID', 'Zip-code']
    users = pd.read_table('./ml-1m/users.dat', sep='::', header=None, names=users_title, engine = 'python')
    users = users.filter(regex='UserID|Gender|Age|JobID')
    users_orig = users.values#保存一份原始数据
    #改变User数据中性别和年龄
    gender_map = {'F':0, 'M':1}
    users['Gender'] = users['Gender'].map(gender_map)

    age_map = {val:ii for ii,val in enumerate(set(users['Age']))}
    users['Age'] = users['Age'].map(age_map)
    #读取Movie数据集
    movies_title = ['MovieID', 'Title', 'Genres']
    movies = pd.read_table('./ml-1m/movies.dat', sep='::', header=None, names=movies_title, engine = 'python')
    movies_orig = movies.values
    #将Title中的年份去掉
    pattern = re.compile(r'^(.*)\((\d+)\)$')

    title_map = {val:pattern.match(val).group(1) for ii,val in enumerate(set(movies['Title']))}
    movies['Title'] = movies['Title'].map(title_map)
    
    #电影类型转数字字典
    genres_set = set()
    for val in movies['Genres'].str.split('|'):
        genres_set.update(val)

    genres_set.add('<PAD>')
    genres2int = {val:ii for ii, val in enumerate(genres_set)}

    #将电影类型转成等长数字列表，长度是18
    genres_map = {val:[genres2int[row] for row in val.split('|')] for ii,val in enumerate(set(movies['Genres']))}
    #print (genres_map)
    for key in genres_map:
        for cnt in range(max(genres2int.values()) - len(genres_map[key])):
            #print (max(genres2int.values()))
            genres_map[key].insert(len(genres_map[key]) + cnt,genres2int['<PAD>'])
    movies['Genres'] = movies['Genres'].map(genres_map)
    #电影Title转数字字典
    title_set = set()
    for val in movies['Title'].str.split():
        title_set.update(val)
    title_set.add('<PAD>')
    title2int = {val:ii for ii, val in enumerate(title_set)}

    #将电影Title转成等长数字列表，长度是15
    title_count = 15
    title_map = {val:[title2int[row] for row in val.split()] for ii,val in enumerate(set(movies['Title']))}
    for key in title_map:
        for cnt in range(title_count - len(title_map[key])):
            title_map[key].insert(len(title_map[key]) + cnt,title2int['<PAD>'])
    
    movies['Title'] = movies['Title'].map(title_map)

    #读取评分数据集
    ratings_title = ['UserID','MovieID', 'ratings', 'timestamps']
    ratings = pd.read_table('./ml-1m/ratings.dat', sep='::', header=None, names=ratings_title, engine = 'python')
    ratings = ratings.filter(regex='UserID|MovieID|ratings')
    #合并三个表
    data = pd.merge(pd.merge(ratings, users), movies)
    
    #将数据分成X和y两张表
    target_fields = ['ratings']
    features_pd, targets_pd = data.drop(target_fields, axis=1), data[target_fields]
    
    features = features_pd.values
    targets_values = targets_pd.values
    
    return title_count, title_set, genres2int, features, targets_values, ratings, users, movies, data, movies_orig, users_orig

title_count, title_set, genres2int, features, targets_values, ratings, users, movies, data, movies_orig, users_orig = load_data()
pickle.dump((title_count, title_set, genres2int, features, targets_values, ratings, users, movies, data, movies_orig, users_orig), open('preprocess_cnn.p', 'wb'))
title_count, title_set, genres2int, features, targets_values, ratings, users, movies, data, movies_orig, users_orig = pickle.load(open('preprocess_cnn.p', mode='rb'))

def save_params(params):#保存参数
    pickle.dump(params, open('params_cnn.p', 'wb'))
def load_params():# 从文件导入参数
    return pickle.load(open('params_cnn.p', mode='rb'))

class ConvLayer(object):
    #构造函数self相当于this指针
    def __init__(self, inpt, filter_shape, strides=(1, 1, 1, 1), padding="SAME", activation=tf.nn.relu, bias_setting=True):
        # 设置输入;
        self.input = inpt
        # 初始化卷积核;
        self.W = tf.Variable(tf.truncated_normal(filter_shape, stddev=0.1), dtype=tf.float32)
        if bias_setting:
            self.b = tf.Variable(tf.truncated_normal(filter_shape[-1:], stddev=0.1),dtype=tf.float32)
        else:
            self.b = None
        # 计算卷积操作的输出;
        conv_output = tf.nn.conv2d(self.input, filter=self.W, strides=strides,padding=padding)                                   
        conv_output = conv_output + self.b if self.b is not None else conv_output
        # 设置输出;
        self.output = conv_output if activation is None else activation(conv_output)
        # 设置参数;
        self.params = [self.W, self.b] if self.b is not None else [self.W, ]

class MaxPoolLayer(object):
    def __init__(self, inpt, ksize=(1, 2, 2, 1), strides=(1, 2, 2, 1), padding="SAME"):
        # 设置输入;
        self.input = inpt
        # 计算输出;
        self.output = tf.nn.max_pool(self.input, ksize=ksize, strides=strides, padding=padding)
        self.params = []

# Flatten层用来将输入“压平”,即把多维的输入一维化,常用在从卷积层到全连接层的过渡;
class FlattenLayer(object):
    def __init__(self, inpt, shape):        
        self.input = inpt
        self.output = tf.reshape(self.input, shape=shape)
        self.params = []

class Fullyconlayer(object):
    def __init__(self,inpt,n_in,n_out,activation=tf.nn.relu): 
        self. W=tf.Variable(tf.truncated_normal([n_in,n_out], stddev=0.1), dtype=tf.float32)
        self. b=tf.Variable(tf.truncated_normal([n_in,n_out][-1:], stddev=0.1),dtype=tf.float32)
        self.input=inpt
        self.output=activation(tf.add(tf.matmul(self.input,self. W),self. b))
        self.n_in=n_in
        self.n_out=n_out
        self.params = [self. W,self. b]

#keep_prob: 设置神经元被选中的概率 float (0, 1];
class DropoutLayer(object):
    def __init__(self, inpt, keep_prob):
        # 设置keep_prob;
        self.keep_prob = 1
        self.input = inpt
        # 计算输出;
        self.output = tf.nn.dropout(self.input, keep_prob=self.keep_prob)
        # 设置train_dicts;
        self.train_dicts = {self.keep_prob: keep_prob}
        # 设置pred_dicts;
        self.pred_dicts = {self.keep_prob: 1.0}    

#uid_dropoutlayer=DropoutLayer(uid_fulluconlayer)


#嵌入矩阵的维度
embed_dim = 32
#用户ID个数
uid_max = max(features.take(0,1)) + 1 # 6040
#性别个数
gender_max = max(features.take(2,1)) + 1 # 1 + 1 = 2
#年龄类别个数
age_max = max(features.take(3,1)) + 1 # 6 + 1 = 7
#职业个数
job_max = max(features.take(4,1)) + 1# 20 + 1 = 21

#电影ID个数
movie_id_max = max(features.take(1,1)) + 1 # 3952
#电影类型个数
movie_categories_max = max(genres2int.values()) + 1 # 18 + 1 = 19
#电影名单词个数
movie_title_max = len(title_set) # 5216

#对电影类型嵌入向量做加和操作的标志，考虑过使用mean做平均，但是没实现mean
combiner = "sum"
 
#卷积核
filter_size=3

#电影名长度
sentences_size = title_count # = 15
#文本卷积滑动窗口，分别滑动2, 3, 4, 5个单词
window_sizes = {2, 3, 4, 5 }
#文本卷积核数量
filter_num = 8

#电影ID转下标的字典，数据集中电影ID跟下标不一致，比如第5行的数据电影ID不一定是5
movieid2idx = {val[0]:i for i, val in enumerate(movies.values)}
#参数是模型内部的配置变量，可以用数据估计其值；超参数是模型外部的配置，必须手动设置其值
# Number of Epochs定义超参
num_epochs = 11      
# Batch Size
batch_size = 256

dropout_keep = 0.5
# Learning Rate
learning_rate = 0.01
# Show stats for every n number of batches每n个用户输出一次
show_every_n_batches = 20

f_num=8

results2(num_epochs,learning_rate,batch_size,f_num)
save_dir = '.cnn/save'

#输入
def get_inputs():
    uid = tf.placeholder(tf.int32, [None, 1], name="uid")#定义用户ID变量
    user_gender = tf.placeholder(tf.int32, [None, 1], name="user_gender")#定义用户性别变量
    user_age = tf.placeholder(tf.int32, [None, 1], name="user_age")#定义用户年龄变量
    user_job = tf.placeholder(tf.int32, [None, 1], name="user_job")#定义用户工作变量
    
    movie_id = tf.placeholder(tf.int32, [None, 1], name="movie_id")#定义电影ID变量
    movie_categories = tf.placeholder(tf.int32, [None, 18], name="movie_categories")#定义电影类型
    movie_titles = tf.placeholder(tf.int32, [None, 15], name="movie_titles")#定义电影名变量
    targets = tf.placeholder(tf.int32, [None, 1], name="targets")#定义学习目标变量
    LearningRate = tf.placeholder(tf.float32, name = "LearningRate")#定义学习率
    dropout_keep_prob = tf.placeholder(tf.float32, name = "dropout_keep_prob")
    return uid, user_gender, user_age, user_job, movie_id, movie_categories, movie_titles, targets, LearningRate, dropout_keep_prob

#构建神经网络：嵌入层
def get_user_embedding(uid, user_gender, user_age, user_job):
    with tf.name_scope("user_embedding"):#在变量作用域内
        uid_embed_matrix = tf.Variable(tf.random_uniform([uid_max, embed_dim], -1, 1), name = "uid_embed_matrix")
        #print (uid_embed_matrix)        
        uid_embed_layer = tf.nn.embedding_lookup(uid_embed_matrix, uid, name = "uid_embed_layer")
        print (uid_embed_layer)
        #tf.nn.embedding_lookup（张量，维数，张量名，激活函数）选取张量里面索引对应的元素
        gender_embed_matrix = tf.Variable(tf.random_uniform([gender_max, embed_dim ], -1, 1), name= "gender_embed_matrix")
        gender_embed_layer = tf.nn.embedding_lookup(gender_embed_matrix, user_gender, name = "gender_embed_layer")
        #print (gender_embed_layer)
        age_embed_matrix = tf.Variable(tf.random_uniform([age_max, embed_dim], -1, 1), name="age_embed_matrix")
        age_embed_layer = tf.nn.embedding_lookup(age_embed_matrix, user_age, name="age_embed_layer")
        #print (age_embed_layer)
        job_embed_matrix = tf.Variable(tf.random_uniform([job_max, embed_dim], -1, 1), name = "job_embed_matrix")
        job_embed_layer = tf.nn.embedding_lookup(job_embed_matrix, user_job, name = "job_embed_layer")
        #print (job_embed_layer)
        return uid_embed_layer, gender_embed_layer, age_embed_layer, job_embed_layer

#定义Movie ID的嵌入矩阵  
def get_movie_id_embed_layer(movie_id):
    with tf.name_scope("movie_embedding"):
        movie_id_embed_matrix = tf.Variable(tf.random_uniform([movie_id_max, embed_dim], -1, 1), name = "movie_id_embed_matrix")
        movie_id_embed_layer = tf.nn.embedding_lookup(movie_id_embed_matrix, movie_id, name = "movie_id_embed_layer")
        #print (movie_id_embed_layer)
        return movie_id_embed_layer
    
#对电影类型的多个嵌入向量做加和
def get_movie_categories_layers(movie_categories):
    with tf.name_scope("movie_categories_layers"):
        movie_categories_embed_matrix = tf.Variable(tf.random_uniform([movie_categories_max, embed_dim], -1, 1), name = "movie_categories_embed_matrix")
        movie_categories_embed_layer = tf.nn.embedding_lookup(movie_categories_embed_matrix, movie_categories, name = "movie_categories_embed_layer")
        #print (movie_categories_embed_layer)
        if combiner == "sum":
            movie_categories_embed_layer = tf.reduce_sum(movie_categories_embed_layer, axis=1, keepdims=True)
            #print (movie_categories_embed_layer)
        #elif combiner == "mean":
        return movie_categories_embed_layer 

#对事先构造好的用户大嵌入矩阵进行卷积（填充0），池化，压平，全连接，以及防止过拟合 
def user_cnn(uid_embed_layer,gender_embed_layer,age_embed_layer, job_embed_layer):
    user_embed_layer=tf.concat([uid_embed_layer,gender_embed_layer,age_embed_layer, job_embed_layer],2)
    #print (user_embed_layer)
    user_reshape=tf.reshape(user_embed_layer,[-1,8,16,1])
    #print(user_reshape.shape)
    user_convlayer=ConvLayer(user_reshape,filter_shape=[3,3,1,f_num],strides=(1, 1, 1, 1), padding="SAME", activation=tf.nn.relu)
    #print(user_convlayer.output)
    user_maxpoollayer=MaxPoolLayer(user_convlayer.output,ksize=(1, 2, 2, 1), strides=(1, 2, 2, 1))
    #print (user_maxpoollayer.output)
    user_flattenlayer=FlattenLayer(user_maxpoollayer.output,[-1,4*8*f_num])
    #print (user_flattenlayer.output)
    user_fullycon=Fullyconlayer(user_flattenlayer.output,4*8*f_num ,32,activation=tf.nn.relu)
    #print (user_fullycon.output)
    user_dropout=DropoutLayer(user_fullycon.output,0.5)      
    return user_dropout


#将卷积好的特征连接起来再次进行全连接
def user_fc_all(user_dropout):
    with tf.name_scope("user_fc"):   
        user_combinelayer=tf.layers.dense(user_dropout.output,32,name = "movie_fc_layer", activation=tf.nn.relu)
        user_combinelayer=tf.contrib.layers.fully_connected(user_combinelayer,200,tf.nn.relu)
        user_combinelayer_falt=tf.reshape(user_combinelayer,[-1,200])
        #print (user_combinelayer_falt)
        return user_combinelayer,user_combinelayer_falt
        #print (user_combinelayer_falt)

#对事先构造好的电影嵌入矩阵进行卷积（填充0），池化，压平，全连接，以及防止过拟合   
def movie_nn(movie_id_embed_layer,movie_categories_embed_layer):
    movie_embed_layer=tf.concat([movie_id_embed_layer,movie_categories_embed_layer],2)
    movie_reshape=tf.reshape(movie_embed_layer,[-1,8,8,1])
    movie_convlayer=ConvLayer(movie_reshape,filter_shape=[3,3,1,f_num],strides=(1, 1, 1, 1), padding="SAME", activation=tf.nn.relu) 
    movie_maxpoollayer=MaxPoolLayer(movie_convlayer.output,ksize=(1, 2, 2, 1), strides=(1, 2, 2, 1))
    movie_flattenlayer=FlattenLayer(movie_maxpoollayer.output,[-1,4*4*f_num])
    movie_fullycon=Fullyconlayer(movie_flattenlayer.output,4*4*f_num ,32,activation=tf.nn.relu)
    movie_dropout=DropoutLayer(movie_fullycon.output,0.5) 
    #print (movie_dropout.output)
    return movie_dropout

#Movie Title的文本卷积网络实现
def get_movie_cnn_layer(movie_titles):
    #从嵌入矩阵中得到电影名对应的各个单词的嵌入向量
    with tf.name_scope("movie_embedding"):
        movie_title_embed_matrix = tf.Variable(tf.random_uniform([movie_title_max, embed_dim], -1, 1), name = "movie_title_embed_matrix")
        movie_title_embed_layer = tf.nn.embedding_lookup(movie_title_embed_matrix, movie_titles, name = "movie_title_embed_layer")
        #print (movie_title_embed_layer)
        movie_title_embed_layer_expand = tf.expand_dims(movie_title_embed_layer, -1)
        #print (movie_title_embed_layer_expand)
    #对文本嵌入层使用不同尺寸的卷积核做卷积和最大池化
    pool_layer_lst = []
    for window_size in window_sizes:
        with tf.name_scope("movie_txt_conv_maxpool_{}".format(window_size)):
            filter_weights = tf.Variable(tf.truncated_normal([window_size, embed_dim, 1, filter_num],stddev=0.1),name = "filter_weights")
            filter_bias = tf.Variable(tf.constant(0.1,shape=[filter_num]),name="filter_bias")
            #print (filter_weights)
            #卷积
            conv_layer = tf.nn.conv2d(movie_title_embed_layer_expand, filter_weights, [1,1,1,1], padding="VALID", name="conv_layer")
            relu_layer = tf.nn.relu(tf.nn.bias_add(conv_layer,filter_bias), name ="relu_layer")
            #print (relu_layer)
            #print (conv_layer)
            #池化
            maxpool_layer = tf.nn.max_pool(relu_layer, [1,sentences_size - window_size + 1 ,1,1], [1,1,1,1], padding="VALID", name="maxpool_layer")
            pool_layer_lst.append(maxpool_layer)
            #print (pool_layer_lst)

    #Dropout层，防止过拟合
    with tf.name_scope("pool_dropout"):
        pool_layer = tf.concat(pool_layer_lst, 3, name ="pool_layer")
        max_num = len(window_sizes) * filter_num
        pool_layer_flat = tf.reshape(pool_layer , [-1,max_num], name = "pool_layer_flat")
    
        dropout_layer = tf.nn.dropout(pool_layer_flat, dropout_keep_prob, name = "dropout_layer")
        #print (dropout_layer)
        return pool_layer_flat, dropout_layer
    
def movie_fc_all(movie_dropout,dropout_layer):
    with tf.name_scope("movie_fc"):
        mtitle_fc_layer=tf.layers.dense(dropout_layer,32,name="mtitle_fc_layer",activation=tf.nn.relu)
        #print (mtitle_fc_layer)
        movie_combinelayer=tf.concat([movie_dropout.output,mtitle_fc_layer],1)
        #print (movie_combinelayer)
        movie_combinelayer=tf.contrib.layers.fully_connected(movie_combinelayer,200,tf.nn.relu)
        #print (movie_combinelayer)
        movie_combinelayer_flat=tf.reshape(movie_combinelayer,[-1,200])
        #print (movie_combinelayer_flat)
        return movie_combinelayer,movie_combinelayer_flat
    
'''def att_user():
    inputs = Input(shape=(input_dim,))

    # ATTENTION PART STARTS HERE
    attention_probs = Dense(input_dim, activation='softmax', name='attention_vec')(inputs)
    print('******',attention_probs)
    attention_mul = multiply([inputs, attention_probs], name='attention_mul')

    attention_mul = Dense(64)(attention_mul)
    output = Dense(1, activation='sigmoid')(attention_mul)
    model = Model(inputs=[inputs], outputs=output)
    return model'''

#构建计算图
tf.reset_default_graph()#重置全局默认图
graph = tf.Graph()#定义一个自己的训练图
#将我们定义的图作为默认图
with graph.as_default():
    #获取输入占位符
    print("&&&&&&&&&&&&&&&&&&&&&&&&")
    uid, user_gender, user_age, user_job, movie_id, movie_categories, movie_titles, targets, lr, dropout_keep_prob= get_inputs()
    #获取User的4个嵌入向量
    uid_embed_layer, gender_embed_layer, age_embed_layer, job_embed_layer = get_user_embedding(uid, user_gender, user_age, user_job)
    #得到用户特征    
    user_dropout=user_cnn(uid_embed_layer,gender_embed_layer,age_embed_layer, job_embed_layer)
    user_combine_layer, user_combine_layer_flat = user_fc_all(user_dropout)   
    #获取电影ID的嵌入向量
    movie_id_embed_layer = get_movie_id_embed_layer(movie_id)
    #获取电影类型的嵌入向量
    movie_categories_embed_layer = get_movie_categories_layers(movie_categories)
    #获取电影名的特征向量
    pool_layer_flat, dropout_layer = get_movie_cnn_layer(movie_titles)
    #得到电影特征
    movie_dropout=movie_nn(movie_id_embed_layer,movie_categories_embed_layer)
    movie_combine_layer, movie_combine_layer_flat = movie_fc_all(movie_dropout,dropout_layer)
    
    #计算出评分，要注意两个不同的方案，inference的名字（name值）是不一样的，后面做推荐时要根据name取得tensor
    with tf.name_scope("predict"):
        predict = tf.reduce_sum(user_combine_layer_flat * movie_combine_layer_flat, axis=1)
        #print (predict)
        predict = tf.expand_dims(predict, axis=1)
        #print (predict)

    with tf.name_scope("loss"):# MSE损失，将计算值回归到评分
        cost = tf.losses.mean_squared_error(targets, predict )#计算MSE
        loss = tf.reduce_mean(cost)#对MSE求平均值
    # 优化损失 
    #train_op = tf.train.AdamOptimizer(lr).minimize(loss)  #cost
    global_step = tf.Variable(0, name="global_step", trainable=False)
    optimizer = tf.train.AdamOptimizer(lr)

    gradients = optimizer.compute_gradients(loss)  #cost
    train_op = optimizer.apply_gradients(gradients, global_step=global_step)
predict

#**********************************训练部分*************************************************
def get_batches(Xs, ys, batch_size):
    for start in range(0, len(Xs), batch_size):
        end = min(start + batch_size, len(Xs))
        yield Xs[start:end], ys[start:end]        
losses = {'train':[], 'test':[]}
list1=[]
list2=[]
with tf.Session(graph=graph) as sess:
    
    #搜集数据给tensorBoard用
    # Keep track of gradient values and sparsity记录梯度和稀疏度
    print("*********************")
    grad_summaries = []
    for g, v in gradients:
        if g is not None:
            grad_hist_summary = tf.summary.histogram("{}/grad/hist".format(v.name.replace(':', '_')), g)
            sparsity_summary = tf.summary.scalar("{}/grad/sparsity".format(v.name.replace(':', '_')), tf.nn.zero_fraction(g))
            grad_summaries.append(grad_hist_summary)
            grad_summaries.append(sparsity_summary)
    grad_summaries_merged = tf.summary.merge(grad_summaries)
        
    # Output directory for models and summaries模型和摘要的目录输出
    timestamp = str(int(time.time()))
    out_dir = os.path.abspath(os.path.join(os.path.curdir, "runs", timestamp))
    print("Writing to {}\n".format(out_dir))
     
    # Summaries for loss and accuracy误差和精确度的摘要
    loss_summary = tf.summary.scalar("loss", loss)

    # Train Summaries（训练摘要）
    train_summary_op = tf.summary.merge([loss_summary, grad_summaries_merged])
    train_summary_dir = os.path.join(out_dir, "summaries", "train")
    train_summary_writer = tf.summary.FileWriter(train_summary_dir, sess.graph)

    # Inference summaries
    inference_summary_op = tf.summary.merge([loss_summary])
    inference_summary_dir = os.path.join(out_dir, "summaries", "predict")
    inference_summary_writer = tf.summary.FileWriter(inference_summary_dir, sess.graph)

    sess.run(tf.global_variables_initializer())
    saver = tf.train.Saver()
    #将数据集分成训练集和测试集，随机种子不固定
    train_X,test_X, train_y, test_y = train_test_split(features,  
                                                           targets_values,  
                                                           test_size = 0.2,  
                                                           random_state = 0  )  
    a=np.array(8)
    for x,y in zip(train_X,train_y): 
        a=np.hstack((x,y)) 
        list1.append(a)          
        #根据一个关键字排序
    list1.sort(key=operator.itemgetter(0))         
    b=np.array(8)
    for x,y in zip(test_X,test_y): 
        b=np.hstack((x,y)) 
        list2.append(b)
    list2.sort(key=operator.itemgetter(0))                    
    for epoch_i in range(num_epochs): 
       
        train_batches = get_batches(train_X, train_y, batch_size)
        test_batches = get_batches(test_X, test_y, batch_size)   
        
                     
        #训练的迭代，保存训练损失
        for batch_i in range(len(train_X) // batch_size):
            x, y = next(train_batches)

            categories = np.zeros([batch_size, 18])
            for i in range(batch_size):
                categories[i] = x.take(6,1)[i]

            titles = np.zeros([batch_size, sentences_size])
            for i in range(batch_size):
                titles[i] = x.take(5,1)[i]

            feed = {
                uid: np.reshape(x.take(0,1), [batch_size, 1]),
                user_gender: np.reshape(x.take(2,1), [batch_size, 1]),
                user_age: np.reshape(x.take(3,1), [batch_size, 1]),
                user_job: np.reshape(x.take(4,1), [batch_size, 1]),
                movie_id: np.reshape(x.take(1,1), [batch_size, 1]),
                movie_categories: categories,  #x.take(6,1)
                movie_titles: titles,  #x.take(5,1)
                targets: np.reshape(y, [batch_size, 1]),
                dropout_keep_prob: dropout_keep, #dropout_keep
                lr: learning_rate}

            step, train_loss, summaries, _ = sess.run([global_step, loss, train_summary_op, train_op], feed)  #cost
            losses['train'].append(train_loss)
            train_summary_writer.add_summary(summaries, step)  
            
    
            # Show every <show_every_n_batches> batches
            if (epoch_i * (len(train_X) // batch_size) + batch_i) % show_every_n_batches == 0:
                time_str = datetime.datetime.now().isoformat()
                print('{}: Epoch {:>3} Batch {:>4}/{}   train_loss = {:.3f}'.format(
                    time_str,
                    epoch_i,
                    batch_i,
                    (len(train_X) // batch_size),
                    train_loss))
    saver.save(sess, save_dir)  #global_step=epoch_i
    print('Model Trained and Saved')   
    
save_params((save_dir))
load_dir = load_params()
#显示训练的loss
plt.plot(losses['train'], label='Training loss')
plt.legend()
_ = plt.ylim()

def get_tensors(loaded_graph):

    uid = loaded_graph.get_tensor_by_name("uid:0")
    user_gender = loaded_graph.get_tensor_by_name("user_gender:0")
    user_age = loaded_graph.get_tensor_by_name("user_age:0")
    user_job = loaded_graph.get_tensor_by_name("user_job:0")
    movie_id = loaded_graph.get_tensor_by_name("movie_id:0")
    movie_categories = loaded_graph.get_tensor_by_name("movie_categories:0")
    movie_titles = loaded_graph.get_tensor_by_name("movie_titles:0")
    targets = loaded_graph.get_tensor_by_name("targets:0")
    dropout_keep_prob = loaded_graph.get_tensor_by_name("dropout_keep_prob:0")
    lr = loaded_graph.get_tensor_by_name("LearningRate:0")
    #两种不同计算预测评分的方案使用不同的name获取tensor inference
#     inference = loaded_graph.get_tensor_by_name("inference/inference/BiasAdd:0")
    predict = loaded_graph.get_tensor_by_name("predict/ExpandDims:0") # 之前是MatMul:0 因为inference代码修改了 这里也要修改 感谢网友 @清歌 指出问题
    movie_combine_layer_flat = loaded_graph.get_tensor_by_name("movie_fc/Reshape:0")
    user_combine_layer_flat = loaded_graph.get_tensor_by_name("user_fc/Reshape:0")
    return uid, user_gender, user_age, user_job, movie_id, movie_categories, movie_titles, targets, lr, dropout_keep_prob, predict, movie_combine_layer_flat, user_combine_layer_flat

    
        
def MAE_movie():
    eachusermovie=0
    eachusersum=0
    i=1
    allsum=0
    countuser=0
    allrmsesum=0
    eachrmsesum=0
    loaded_graph = tf.Graph()  
    with tf.Session(graph=loaded_graph) as sess:  
    # Load saved model
        loader = tf.train.import_meta_graph(load_dir + '.meta')
        loader.restore(sess, load_dir)
     
    # Get Tensors from loaded model
        uid, user_gender, user_age, user_job, movie_id, movie_categories, movie_titles, targets, lr, dropout_keep_prob,  predict ,_, __ = get_tensors(loaded_graph)
        
        for item in list2:           
            categories = np.zeros([1, 18])
            categories[0] = movies.values[movieid2idx[item.take(1)]][2]

            titles = np.zeros([1, sentences_size])
            titles[0] = movies.values[movieid2idx[item.take(1)]][1]

            feed = {
                uid: np.reshape(users.values[item.take(0)-1][0], [1, 1]),
                user_gender: np.reshape(users.values[item.take(0)-1][1], [1, 1]),
                user_age: np.reshape(users.values[item.take(0)-1][2], [1, 1]),
                user_job: np.reshape(users.values[item.take(0)-1][3], [1, 1]),
                movie_id: np.reshape(movies.values[movieid2idx[item.take(1)]][0], [1, 1]),
                movie_categories: categories, 
                movie_titles: titles, 
                dropout_keep_prob: 1}
            predict_val = sess.run([predict], feed)#计算预测评分   
            #print(str(item[0])+"号用户对"+"电影"+str(item[1])+"的预测评分为:"+str(np.squeeze(inference_val[0])))
            if item[0]!=i:#用户切换输出上一个用户的MAE
                countuser+=1              
                eachMAE=eachusersum/eachusermovie 
                eachrmse=sqrt(eachrmsesum/eachusermovie)
                allsum=allsum+eachMAE
                allrmsesum=allrmsesum+eachrmse
                print(str(i)+"号用户对电影评分的平均MAE为:"+str(eachMAE))                               
                eachusersum=0
                eachusermovie=0
                eachrmsesum=0
            i=item[0]#记住上一个用户
            eachusermovie+=1
            eachusersum=eachusersum+abs(item[7]-np.squeeze( predict_val[0]))
            eachrmsesum=eachrmsesum+(item[7]-np.squeeze( predict_val[0]))*(item[7]-np.squeeze( predict_val[0]))
            
                     
        avgrating=allsum/countuser
        avgrmse=allrmsesum/countuser
        s="MAE为："
        results1(avgrating,s)
        s="RMSE为："
        results1(avgrmse,s)
        print("联合嵌入CNN-所有用户对电影评分的平均MAE为:"+str(avgrating))
        print("联合嵌入CNN-所有用户对电影评分的平均RMSE为:"+str(avgrmse))
           
MAE_movie()          

'''#生成movie特征矩阵
loaded_graph = tf.Graph()  
movie_matrics = []
with tf.Session(graph=loaded_graph) as sess:  #
    # Load saved model
    loader = tf.train.import_meta_graph(load_dir + '.meta')
    loader.restore(sess, load_dir)

    # Get Tensors from loaded model  
    uid, user_gender, user_age, user_job, movie_id, movie_categories, movie_titles, targets, lr, dropout_keep_prob, _, movie_combine_layer_flat, __ = get_tensors(loaded_graph)  #loaded_graph

    for item in movies.values:
        categories = np.zeros([1, 18])
        categories[0] = item.take(2)

        titles = np.zeros([1, sentences_size])
        titles[0] = item.take(1)

        feed = {
            movie_id: np.reshape(item.take(0), [1, 1]),
            movie_categories: categories,  #x.take(6,1)
            movie_titles: titles,  #x.take(5,1)
            dropout_keep_prob: 1}

        movie_combine_layer_flat_val = sess.run([movie_combine_layer_flat], feed)  
        movie_matrics.append(movie_combine_layer_flat_val)

pickle.dump((np.array(movie_matrics).reshape(-1, 200)), open('movie_matrics.p', 'wb'))
movie_matrics = pickle.load(open('movie_matrics.p', mode='rb'))


#生成User特征矩阵
loaded_graph = tf.Graph()  
users_matrics = []
with tf.Session(graph=loaded_graph) as sess:  #
    # Load saved model
    loader = tf.train.import_meta_graph(load_dir + '.meta')
    loader.restore(sess, load_dir)

    # Get Tensors from loaded model
    uid, user_gender, user_age, user_job, movie_id, movie_categories, movie_titles, targets, lr, dropout_keep_prob, _, __,user_combine_layer_flat = get_tensors(loaded_graph)  #loaded_graph

    for item in users.values:
        feed = {
            uid: np.reshape(item.take(0), [1, 1]),
            user_gender: np.reshape(item.take(1), [1, 1]),
            user_age: np.reshape(item.take(2), [1, 1]),
            user_job: np.reshape(item.take(3), [1, 1]),
            dropout_keep_prob: 1}#填充数据

        user_combine_layer_flat_val = sess.run([user_combine_layer_flat], feed)#计算
        users_matrics.append(user_combine_layer_flat_val)

pickle.dump((np.array(users_matrics).reshape(-1, 200)), open('users_matrics.p', 'wb'))
users_matrics = pickle.load(open('users_matrics.p', mode='rb'))

def recommend_your_favorite_movie(user, top_k ):
    loaded_graph = tf.Graph()
    with tf.Session(graph=loaded_graph) as sess:  #
        # Load saved model
        loader = tf.train.import_meta_graph(load_dir + '.meta')
        loader.restore(sess, load_dir)
        probs_embeddings = (users_matrics[user-1]).reshape([1, 200])
        probs_similarity = tf.matmul(probs_embeddings, tf.transpose(movie_matrics))
        sim = (probs_similarity.eval())
         
        results = (-sim[0]).argsort()[0:top_k]
        recommend=dict()
            
        for val in (results):            
            recommend[val]=movies_orig[val]

        return recommend
        

#训练集用户电影评分字典
train=dict()
P=dict()
for item in list1:
    u=item[0]
    o=item[1]
    rating=item[2]
    P[o]=rating
    if u in train.keys():
        train[u].update(deepcopy(P))
    else:
        train[u]=deepcopy(P)
    P.clear()
 #测试集用户电影评分字典   
test=dict()
O=dict()
for item in list2:
    u=item[0]
    o=item[1]
    rating=item[2]
    O[o]=rating
    if u in test.keys():
        test[u].update(deepcopy(O))
    else:
        test[u]=deepcopy(O)
    O.clear()

     
#出现在推荐列表中的用户喜欢的物品占用户所喜欢过的物品的百分比
def Recall(train, test, N):  
    hit = 0#推荐列表中
    all1 = 0#用户喜欢过的物品
    all2=0
    for user in train.keys():
        if user in test:
            tu = test[user]
            all1+= len(tu)
            all2+=10
            rank = recommend_your_favorite_movie(user, 10)
            print("完成"+str(user)+"用户的推荐列表。")
            for item in rank.values():
                if item[0] in tu:
                    hit +=1	                                                        
    rec=hit / (all1 * 1.0)
    pre=hit / (all2 * 1.0)
    s="联合嵌入此次命中：" 
    results1(hit,s)
    s="召回率,准确率为："  
    results(rec,pre,s) 
    print("联合嵌入此次命中"+str(hit))
    print("召回率为"+str(rec))
    print("准确率为"+str(pre))
#Recall(train,test, 10)

def precision(train, test, N):
    hit = 0
    all2 = 0
    for user in train.keys():
        if user<=1000:
            if user in test:
                tu = test[user]
                all2+=10
                rank = recommend_your_favorite_movie(user, 10)
                print("完成"+str(user)+"用户的推荐列表。")
                for item in rank.values():
                    if item[0] in tu:
                        hit +=1	                                  
        else:
            break
    pre=hit / (all2 * 1.0)
    s="联合嵌入此次命中：" 
    results1(hit,s) 
    s="准确率为："
    results1(pre,s)
    print("准确率为"+str(pre))
  
#precision(train, test, 10) 

def Coverage(train,test,N):
    recommend_items = []
    all_items = []
    for user in train.keys():
        for item in train[user].keys():
	          all_items.append(item)
        rank = recommend_your_favorite_movie(user, 10)	      
        for item in rank.values():
	          recommend_items.append(item)

    co=len(recommend_items) / (len(all_items) * 1.0)
    s="覆盖率为："
    results(co,s)
    print("覆盖率为"+str(co))
    return len(recommend_items) / (len(all_items) * 1.0)

#Coverage(train,test,10)'''

